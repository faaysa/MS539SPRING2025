﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace KearsargeMapSimulation
{
    public class MainForm : Form
    {
        private Panel mainPanel;
        private Button btnHangar, btnCommand, btnMedical, btnMess, btnQuarters, btnEngine;
        private Label displayLabel;

        public MainForm()
        {
            // Set basic form properties
            this.Text = "USS Kearsarge (LHD-3) Interior Simulation";
            this.Size = new Size(800, 500);

            // Initialize UI components
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Main display area
            mainPanel = new Panel
            {
                Size = new Size(580, 400),
                Location = new Point(200, 20),
                BorderStyle = BorderStyle.Fixed3D
            };

            displayLabel = new Label
            {
                AutoSize = false,
                Size = mainPanel.Size,
                Font = new Font("Consolas", 12),
                TextAlign = ContentAlignment.MiddleLeft
            };
            mainPanel.Controls.Add(displayLabel);

            // Initialize buttons for navigation
            btnHangar = CreateButton("Hangar Bay", 20, 20, ShowHangarBay);
            btnCommand = CreateButton("Command Center", 20, 70, ShowCommandCenter);
            btnMedical = CreateButton("Medical Bay", 20, 120, ShowMedicalBay);
            btnMess = CreateButton("Mess Decks", 20, 170, ShowMessDecks);
            btnQuarters = CreateButton("Sleeping Quarters", 20, 220, ShowSleepingQuarters);
            btnEngine = CreateButton("Engine Room", 20, 270, ShowEngineRoom);

            // Add controls to the Form
            this.Controls.AddRange(new Control[]
            {
btnHangar, btnCommand, btnMedical,
btnMess, btnQuarters, btnEngine,
mainPanel
            });
        }

        // Helper to create buttons with a click event
        private Button CreateButton(string text, int x, int y, EventHandler handler)
        {
            var button = new Button
            {
                Text = text,
                Size = new Size(150, 40),
                Location = new Point(x, y)
            };
            button.Click += handler;
            return button;
        }

        // Module 1: Hangar Bay Viewer
        private void ShowHangarBay(object sender, EventArgs e)
        {
            displayLabel.Text =
            "🚁 Hangar Bay\n\n" +
            "- 3x CH-53E Helicopters onboard\n" +
            "- 2x AV-8B Harriers stowed aft\n" +
            "- Pathways: East → Maintenance, West → Flight Deck\n" +
            "- Safety: Green light – Clear to move\n";
        }

        // Module 2: Command Center Map
        private void ShowCommandCenter(object sender, EventArgs e)
        {
            displayLabel.Text =
            "🧭 Command Information Center (CIC)\n\n" +
            "- Status: Green\n" +
            "- Tactical Map: All stations operational\n" +
            "- Alert Readiness: DEFCON 5\n" +
            "- Communications: Linked to bridge and radar\n";
        }

        // Module 3: Medical Bay Navigator
        private void ShowMedicalBay(object sender, EventArgs e)
        {
            displayLabel.Text =
            "🩺 Medical Bay\n\n" +
            "- Beds: 12 (8 occupied)\n" +
            "- Isolation Room: Empty\n" +
            "- Equipment: Trauma kits, X-Ray, Defibrillators\n" +
            "- Emergency Drill: Next in 3 days\n";
        }

        // Module 4: Mess Decks Simulation
        private void ShowMessDecks(object sender, EventArgs e)
        {
            displayLabel.Text =
            "🍽️ Mess Decks\n\n" +
            "- Meal Times:\n • Breakfast: 0600-0800\n • Lunch: 1200-1400\n • Dinner: 1800-2000\n" +
            "- Food Supply: Sufficient for 20 days\n" +
            "- Seating Capacity: 150 sailors\n";
        }

        // Module 5: Sleeping Quarters Map
        private void ShowSleepingQuarters(object sender, EventArgs e)
        {
            displayLabel.Text =
            "🛏️ Sleeping Quarters (Berthing)\n\n" +
            "- Deck A: Officers (20 rooms)\n" +
            "- Deck B: Enlisted (200 bunks)\n" +
            "- Deck C: Overflow / Guests\n" +
            "- Current Occupancy: 87%\n";
        }

        // Module 6: Engine Room Monitor
        private void ShowEngineRoom(object sender, EventArgs e)
        {
            displayLabel.Text =
            "⚙️ Engine Room\n\n" +
            "- Propulsion: 2x Steam Turbines\n" +
            "- Fuel Levels: 67% capacity\n" +
            "- Temperature: Stable (230°F)\n" +
            "- Next Maintenance: In 14 days\n";
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new MainForm());
        }
    }
}