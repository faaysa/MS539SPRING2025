﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//AYODELE FATANmi,MS539 2.1 ASSIGNMENT
/*I'M LOOKING TO DO THIS CODE FOR UP TO AN HOUR
 *I USED FEW MINUTES TO DO EACH CODE AND I SPENT LIKE 30MIN
 *IT TOOK ME SHORTER BECAUSE I REEAD AND UNDERTOOD THE CLASS LECTURE
 *I CAN IMPROVE BY MAKING RESEARCH AND DOING MORE INTENSE CODINGG
 */
namespace ms539_assignment_2._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("we are still working on this site but feel free to attempt loggin in");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("can't log in at this time. Feel free to answer the quest. below to know how we can serve you better");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("TAKES LOTS OF DATA");
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("ECONOMICAL");
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("WAY FASTERRRRR");
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("PLEASE DO YOU WILL NOT BE DISAPPOINTED");
        }
    }
}
